export class Employee {
    id: number;
    username: string;
    password: string;
    token: string;
}